import { useState, useEffect } from 'react';

export interface TimeData {
  hours: number;
  minutes: number;
  seconds: number;
  millis: number;
  h12: number;
  ampm: 'AM' | 'PM';
  hourStr: string;
  minuteStr: string;
  secondStr: string;
  millisStr: string;
  h12Str: string;
}

export function useTime() {
  const [time, setTime] = useState<TimeData>(() => getTimeData());

  useEffect(() => {
    let rafId: number;
    function tick() {
      setTime(getTimeData());
      rafId = requestAnimationFrame(tick);
    }
    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, []);

  return time;
}

function getTimeData(): TimeData {
  const now = new Date();
  const h = now.getHours();
  const m = now.getMinutes();
  const s = now.getSeconds();
  const ms = now.getMilliseconds();
  const h12 = h % 12 || 12;
  return {
    hours: h,
    minutes: m,
    seconds: s,
    millis: ms,
    h12,
    ampm: h < 12 ? 'AM' : 'PM',
    hourStr: String(h).padStart(2, '0'),
    minuteStr: String(m).padStart(2, '0'),
    secondStr: String(s).padStart(2, '0'),
    millisStr: String(ms).padStart(3, '0'),
    h12Str: String(h12).padStart(2, '0'),
  };
}
