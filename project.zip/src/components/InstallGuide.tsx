import { useState } from 'react';

export default function InstallGuide() {
  const [isOpen, setIsOpen] = useState(false);
  const [platform, setPlatform] = useState<'android' | 'ios'>('android');

  return (
    <>
      {/* Help button */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-40 w-12 h-12 bg-indigo-600 hover:bg-indigo-500 rounded-full shadow-lg shadow-indigo-500/30 flex items-center justify-center text-white transition-all hover:scale-110"
      >
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      </button>

      {/* Modal */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm" onClick={() => setIsOpen(false)}>
          <div className="bg-gray-900 rounded-2xl p-6 max-w-md w-full max-h-[80vh] overflow-y-auto border border-white/10" onClick={e => e.stopPropagation()}>
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-white">📱 تثبيت التطبيق</h2>
              <button
                onClick={() => setIsOpen(false)}
                className="text-white/40 hover:text-white/80 transition-colors"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            {/* Platform selector */}
            <div className="flex gap-2 mb-6">
              <button
                onClick={() => setPlatform('android')}
                className={`flex-1 py-2 rounded-lg font-medium transition-all ${
                  platform === 'android'
                    ? 'bg-green-600 text-white'
                    : 'bg-white/5 text-white/40 hover:bg-white/10'
                }`}
              >
                🤖 أندرويد
              </button>
              <button
                onClick={() => setPlatform('ios')}
                className={`flex-1 py-2 rounded-lg font-medium transition-all ${
                  platform === 'ios'
                    ? 'bg-blue-600 text-white'
                    : 'bg-white/5 text-white/40 hover:bg-white/10'
                }`}
              >
                🍎 آيفون
              </button>
            </div>

            {/* Instructions */}
            <div className="space-y-4 text-right">
              {platform === 'android' ? (
                <>
                  <div className="flex gap-3">
                    <div className="w-8 h-8 bg-green-600/20 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-green-400 font-bold">1</span>
                    </div>
                    <div>
                      <h3 className="text-white font-medium mb-1">افتح Chrome</h3>
                      <p className="text-white/40 text-sm">افتح هذا الموقع في متصفح Chrome</p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <div className="w-8 h-8 bg-green-600/20 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-green-400 font-bold">2</span>
                    </div>
                    <div>
                      <h3 className="text-white font-medium mb-1">اضغط النقاط الثلاث</h3>
                      <p className="text-white/40 text-sm">في الزاوية العلوية اليمنى</p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <div className="w-8 h-8 bg-green-600/20 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-green-400 font-bold">3</span>
                    </div>
                    <div>
                      <h3 className="text-white font-medium mb-1">اختر "إضافة إلى الشاشة"</h3>
                      <p className="text-white/40 text-sm">أو "تثبيت التطبيق"</p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <div className="w-8 h-8 bg-green-600/20 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-green-400 font-bold">4</span>
                    </div>
                    <div>
                      <h3 className="text-white font-medium mb-1">اضغط "إضافة"</h3>
                      <p className="text-white/40 text-sm">الآن التطبيق جاهز!</p>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div className="flex gap-3">
                    <div className="w-8 h-8 bg-blue-600/20 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-blue-400 font-bold">1</span>
                    </div>
                    <div>
                      <h3 className="text-white font-medium mb-1">افتح Safari</h3>
                      <p className="text-white/40 text-sm">افتح هذا الموقع في متصفح Safari</p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <div className="w-8 h-8 bg-blue-600/20 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-blue-400 font-bold">2</span>
                    </div>
                    <div>
                      <h3 className="text-white font-medium mb-1">اضغط زر المشاركة</h3>
                      <p className="text-white/40 text-sm">المربع مع السهم للأعلى</p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <div className="w-8 h-8 bg-blue-600/20 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-blue-400 font-bold">3</span>
                    </div>
                    <div>
                      <h3 className="text-white font-medium mb-1">اختر "إضافة إلى الشاشة"</h3>
                      <p className="text-white/40 text-sm">Add to Home Screen</p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <div className="w-8 h-8 bg-blue-600/20 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-blue-400 font-bold">4</span>
                    </div>
                    <div>
                      <h3 className="text-white font-medium mb-1">اضغط "إضافة"</h3>
                      <p className="text-white/40 text-sm">في الزاوية العلوية</p>
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Benefits */}
            <div className="mt-6 p-4 bg-white/5 rounded-xl">
              <h4 className="text-white font-medium mb-3">✨ مميزات التطبيق:</h4>
              <ul className="space-y-2 text-sm text-white/60">
                <li className="flex items-center gap-2">
                  <span>✅</span>
                  <span>شاشة كاملة بدون متصفح</span>
                </li>
                <li className="flex items-center gap-2">
                  <span>✅</span>
                  <span>يعمل بدون إنترنت</span>
                </li>
                <li className="flex items-center gap-2">
                  <span>✅</span>
                  <span>أيقونة على الشاشة الرئيسية</span>
                </li>
                <li className="flex items-center gap-2">
                  <span>✅</span>
                  <span>12 ساعة مختلفة</span>
                </li>
              </ul>
            </div>

            {/* Close button */}
            <button
              onClick={() => setIsOpen(false)}
              className="w-full mt-6 py-3 bg-indigo-600 hover:bg-indigo-500 rounded-xl font-semibold text-white transition-all"
            >
              فهمت!
            </button>
          </div>
        </div>
      )}
    </>
  );
}
