import { useMemo } from 'react';
import { useTime } from '../hooks/useTime';

interface BinaryDigits {
  label: string;
  bits: number[];
  value: number;
}

function getBits(value: number, bits: number): number[] {
  const result: number[] = [];
  for (let i = bits - 1; i >= 0; i--) {
    result.push((value >> i) & 1);
  }
  return result;
}

function BinaryColumn({ digits }: { digits: BinaryDigits }) {
  return (
    <div className="flex flex-col items-center gap-3">
      <div className="flex flex-col gap-1.5">
        {digits.bits.map((bit, i) => (
          <div
            key={i}
            className={`
              w-8 h-8 sm:w-10 sm:h-10 rounded-lg
              transition-all duration-300 ease-in-out
              ${
                bit
                  ? 'bg-indigo-500 shadow-[0_0_12px_rgba(99,102,241,0.5)] ring-1 ring-indigo-400/50 scale-100'
                  : 'bg-gray-800/50 ring-1 ring-white/5 scale-90 opacity-40'
              }
            `}
          />
        ))}
      </div>
      <span className="text-[10px] font-mono text-white/30 tabular-nums">
        {digits.value.toString().padStart(2, '0')}
      </span>
    </div>
  );
}

export default function BinaryClock() {
  const t = useTime();

  const columns: BinaryDigits[] = useMemo(
    () => [
      { label: 'H1', bits: getBits(Math.floor(t.hours / 10), 2), value: Math.floor(t.hours / 10) },
      { label: 'H2', bits: getBits(t.hours % 10, 4), value: t.hours % 10 },
      { label: 'M1', bits: getBits(Math.floor(t.minutes / 10), 3), value: Math.floor(t.minutes / 10) },
      { label: 'M2', bits: getBits(t.minutes % 10, 4), value: t.minutes % 10 },
      { label: 'S1', bits: getBits(Math.floor(t.seconds / 10), 3), value: Math.floor(t.seconds / 10) },
      { label: 'S2', bits: getBits(t.seconds % 10, 4), value: t.seconds % 10 },
    ],
    [t.hours, t.minutes, t.seconds],
  );

  // Bit position labels
  const bitLabels = ['8', '4', '2', '1'];

  return (
    <div className="flex flex-col items-center gap-8 animate-[fade-in_0.6s_ease-out]">
      {/* Bit weight labels */}
      <div className="flex gap-[calc(2rem+6px)] sm:gap-[calc(2.5rem+6px)]">
        {[2, 4, 3, 4, 3, 4].map((bits, ci) => (
          <div key={ci} className="flex flex-col gap-1.5" style={{ width: bits > 3 ? '2.5rem' : '2rem' }}>
            {bitLabels.slice(4 - bits).map((label, i) => (
              <div key={i} className="text-[8px] text-center text-white/15 font-mono h-8 sm:h-10 flex items-center justify-center">
                {label}
              </div>
            ))}
          </div>
        ))}
      </div>

      {/* Columns */}
      <div className="flex items-end gap-3 sm:gap-4">
        {columns.map((col, i) => (
          <BinaryColumn key={i} digits={col} />
        ))}
      </div>

      {/* Separator dots */}
      <div className="flex items-center gap-4 sm:gap-5 mt-2">
        <div className="flex gap-3" />
        <div className="w-1.5 h-1.5 rounded-full bg-indigo-400/40 shadow-[0_0_6px_rgba(129,140,248,0.3)]" />
        <div className="w-1.5 h-1.5 rounded-full bg-indigo-400/40 shadow-[0_0_6px_rgba(129,140,248,0.3)]" />
      </div>

      {/* Digital readout */}
      <div className="text-center">
        <div className="text-3xl font-light tracking-[0.15em] text-white/80 tabular-nums font-mono">
          {t.hourStr}:{t.minuteStr}:{t.secondStr}
        </div>
        <div className="text-xs text-white/20 mt-2 font-mono">
          {t.hours.toString(2).padStart(5, '0')} {t.minutes.toString(2).padStart(6, '0')} {t.seconds.toString(2).padStart(6, '0')}
        </div>
      </div>
    </div>
  );
}
