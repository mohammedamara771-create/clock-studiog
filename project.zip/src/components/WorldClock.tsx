import { useTime } from '../hooks/useTime';

const timeZones = [
  { city: 'New York', zone: 'America/New_York', offset: -5 },
  { city: 'London', zone: 'Europe/London', offset: 0 },
  { city: 'Paris', zone: 'Europe/Paris', offset: 1 },
  { city: 'Dubai', zone: 'Asia/Dubai', offset: 4 },
  { city: 'Tokyo', zone: 'Asia/Tokyo', offset: 9 },
  { city: 'Sydney', zone: 'Australia/Sydney', offset: 11 },
];

export default function WorldClock() {
  const t = useTime();

  const getZoneTime = (offset: number) => {
    const utc = t.hours + t.minutes / 60 + t.seconds / 3600;
    let local = utc + offset;
    if (local >= 24) local -= 24;
    if (local < 0) local += 24;
    const h = Math.floor(local);
    const m = Math.floor((local - h) * 60);
    const s = Math.floor(((local - h) * 60 - m) * 60);
    return { h, m, s, ampm: h < 12 ? 'AM' : 'PM', h12: h % 12 || 12 };
  };

  const getDayPhase = (offset: number) => {
    const utc = t.hours;
    let local = utc + offset;
    if (local >= 24) local -= 24;
    if (local < 0) local += 24;
    if (local >= 6 && local < 12) return 'morning';
    if (local >= 12 && local < 18) return 'afternoon';
    if (local >= 18 && local < 22) return 'evening';
    return 'night';
  };

  const phaseColors = {
    morning: 'from-amber-400/30 to-orange-400/30',
    afternoon: 'from-blue-400/30 to-cyan-400/30',
    evening: 'from-purple-400/30 to-pink-400/30',
    night: 'from-indigo-600/30 to-gray-600/30',
  };

  return (
    <div className="flex flex-col items-center gap-6 animate-[fade-in_0.6s_ease-out]">
      <div className="text-sm tracking-[0.3em] text-white/30 font-medium uppercase">
        World Times
      </div>

      <div className="w-full max-w-md">
        <div className="space-y-2">
          {timeZones.map((tz) => {
            const time = getZoneTime(tz.offset);
            const phase = getDayPhase(tz.offset);
            return (
              <div
                key={tz.city}
                className={`relative overflow-hidden rounded-xl p-3 bg-gradient-to-r ${phaseColors[phase]} border border-white/5`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm font-medium text-white/80">{tz.city}</div>
                    <div className="text-xs text-white/40">UTC{tz.offset >= 0 ? '+' : ''}{tz.offset}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xl font-semibold text-white/90 tabular-nums">
                      {String(time.h12).padStart(2, '0')}:{String(time.m).padStart(2, '0')}
                    </div>
                    <div className="text-xs text-white/40">{time.ampm}</div>
                  </div>
                </div>
                {/* Day phase indicator */}
                <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 w-2 h-2 rounded-full bg-white/20" />
              </div>
            );
          })}
        </div>
      </div>

      {/* Your local time */}
      <div className="mt-4 text-center pt-4 border-t border-white/10">
        <div className="text-xs text-white/30 uppercase tracking-wider mb-1">Your Time</div>
        <div className="text-2xl font-semibold text-white/80 tabular-nums">
          {t.hourStr}:{t.minuteStr}:{t.secondStr}
        </div>
      </div>
    </div>
  );
}
