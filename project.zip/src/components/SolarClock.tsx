import { useTime } from '../hooks/useTime';

export default function SolarClock() {
  const t = useTime();

  // Calculate sun position (simplified)
  const totalMinutes = t.hours * 60 + t.minutes;
  const sunrise = 6 * 60; // 6 AM
  const sunset = 18 * 60; // 6 PM
  const dayLength = sunset - sunrise;
  const dayProgress = Math.max(0, Math.min(1, (totalMinutes - sunrise) / dayLength));

  // Sky gradient based on time
  const getSkyGradient = () => {
    if (t.hours < 6 || t.hours >= 20) return 'from-indigo-950 via-purple-950 to-gray-950';
    if (t.hours < 8) return 'from-indigo-900 via-purple-800 to-orange-800';
    if (t.hours < 10) return 'from-blue-800 via-cyan-700 to-orange-600';
    if (t.hours < 16) return 'from-blue-600 via-cyan-500 to-blue-600';
    if (t.hours < 18) return 'from-orange-600 via-red-500 to-purple-700';
    if (t.hours < 20) return 'from-purple-800 via-indigo-900 to-gray-900';
    return 'from-indigo-950 via-purple-950 to-gray-950';
  };

  // Sun color based on time
  const getSunColor = () => {
    if (t.hours < 6 || t.hours >= 20) return 'bg-indigo-300 shadow-[0_0_40px_rgba(165,180,252,0.6)]';
    if (t.hours < 8) return 'bg-orange-300 shadow-[0_0_40px_rgba(253,186,116,0.6)]';
    if (t.hours < 10) return 'bg-yellow-300 shadow-[0_0_40px_rgba(253,224,71,0.6)]';
    if (t.hours < 16) return 'bg-yellow-200 shadow-[0_0_40px_rgba(254,240,138,0.6)]';
    if (t.hours < 18) return 'bg-orange-400 shadow-[0_0_40px_rgba(251,146,60,0.6)]';
    if (t.hours < 20) return 'bg-orange-500 shadow-[0_0_40px_rgba(249,115,22,0.6)]';
    return 'bg-indigo-300 shadow-[0_0_40px_rgba(165,180,252,0.6)]';
  };

  return (
    <div className="flex flex-col items-center gap-6 animate-[fade-in_0.6s_ease-out]">
      <div className="text-sm tracking-[0.3em] text-white/30 font-medium uppercase">
        Solar Time
      </div>

      {/* Sky display */}
      <div className={`relative w-64 h-48 sm:w-72 sm:h-56 rounded-2xl overflow-hidden bg-gradient-to-b ${getSkyGradient()} shadow-2xl`}>
        {/* Stars at night */}
        {(t.hours < 6 || t.hours >= 20) && (
          <div className="absolute inset-0">
            {Array.from({ length: 20 }).map((_, i) => (
              <div
                key={i}
                className="absolute w-0.5 h-0.5 bg-white rounded-full animate-pulse"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 60}%`,
                  animationDelay: `${Math.random() * 2}s`,
                }}
              />
            ))}
          </div>
        )}

        {/* Sun/Moon */}
        <div
          className={`absolute w-12 h-12 sm:w-14 sm:h-14 rounded-full transition-all duration-1000 ${getSunColor()}`}
          style={{
            left: `${10 + dayProgress * 80}%`,
            top: `${30 + Math.sin((dayProgress * Math.PI)) * 20}%`,
            transform: 'translate(-50%, -50%)',
          }}
        />

        {/* Horizon */}
        <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-gray-900 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/10" />

        {/* Time label in sky */}
        <div className="absolute top-4 left-4 text-xs font-mono text-white/50">
          {t.hourStr}:{t.minuteStr}
        </div>
      </div>

      {/* Info */}
      <div className="text-center space-y-2">
        <div className="text-lg font-semibold text-white/80">
          {t.hours < 6 || t.hours >= 20 ? 'Night' : t.hours < 12 ? 'Morning' : t.hours < 18 ? 'Day' : 'Evening'}
        </div>
        <div className="text-sm text-white/40">
          Day Progress: {Math.round(dayProgress * 100)}%
        </div>
      </div>

      {/* Progress bar */}
      <div className="w-48 h-1.5 rounded-full bg-white/10 overflow-hidden">
        <div
          className="h-full rounded-full bg-gradient-to-r from-indigo-500 via-yellow-400 to-orange-500 transition-all duration-300"
          style={{ width: `${dayProgress * 100}%` }}
        />
      </div>
    </div>
  );
}
