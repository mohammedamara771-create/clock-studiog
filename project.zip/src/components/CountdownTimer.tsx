import { useState, useCallback, useEffect, useRef } from 'react';

const PRESETS = [
  { label: '1 min', seconds: 60 },
  { label: '5 min', seconds: 300 },
  { label: '10 min', seconds: 600 },
  { label: '25 min', seconds: 1500 },
  { label: 'Custom', seconds: 0 },
];

export default function CountdownTimer() {
  const [duration, setDuration] = useState(300);
  const [remaining, setRemaining] = useState(300);
  const [isRunning, setIsRunning] = useState(false);
  const intervalRef = useRef<number | null>(null);

  useEffect(() => {
    if (isRunning && remaining > 0) {
      intervalRef.current = window.setInterval(() => {
        setRemaining((prev) => {
          if (prev <= 1) {
            setIsRunning(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isRunning, remaining]);

  const handleStart = useCallback(() => {
    if (remaining === 0) setRemaining(duration);
    setIsRunning(true);
  }, [remaining, duration]);

  const handlePause = useCallback(() => {
    setIsRunning(false);
  }, []);

  const handleReset = useCallback(() => {
    setIsRunning(false);
    setRemaining(duration);
  }, [duration]);

  const handlePreset = useCallback((seconds: number) => {
    setDuration(seconds);
    setRemaining(seconds);
    setIsRunning(false);
  }, []);

  const handleCustom = useCallback(() => {
    const input = prompt('Enter seconds (1-3600):');
    if (input) {
      const secs = Math.min(3600, Math.max(1, parseInt(input) || 0));
      handlePreset(secs);
    }
  }, [handlePreset]);

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    if (h > 0) {
      return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    }
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const progress = ((duration - remaining) / duration) * 100;
  const isComplete = remaining === 0;

  return (
    <div className="flex flex-col items-center gap-6 animate-[fade-in_0.6s_ease-out]">
      <div className="text-sm tracking-[0.3em] text-white/30 font-medium uppercase">
        Countdown
      </div>

      {/* Timer display */}
      <div className={`relative w-56 h-56 rounded-full flex items-center justify-center border-4 ${
        isComplete ? 'border-green-500/50 bg-green-500/10' :
        isRunning ? 'border-rose-500/50 bg-rose-500/10' :
        'border-violet-500/50 bg-violet-500/10'
      } shadow-2xl transition-all duration-500`}>
        {/* Progress ring */}
        <svg className="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 100 100">
          <circle
            cx="50" cy="50" r="45"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            className="text-white/5"
          />
          <circle
            cx="50" cy="50" r="45"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            strokeDasharray={283}
            strokeDashoffset={283 - (progress / 100) * 283}
            strokeLinecap="round"
            className={`transition-all duration-1000 ${
              isComplete ? 'text-green-400' :
              isRunning ? 'text-rose-400' :
              'text-violet-400'
            }`}
          />
        </svg>
        <div className={`text-3xl sm:text-4xl font-bold tabular-nums ${
          isComplete ? 'text-green-400' :
          isRunning ? 'text-rose-400' :
          'text-violet-400'
        }`}>
          {formatTime(remaining)}
        </div>
        {isComplete && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-green-400 text-sm font-medium animate-pulse">DONE!</div>
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="flex gap-3">
        {!isRunning ? (
          <button
            onClick={handleStart}
            className="px-6 py-3 rounded-xl font-semibold text-sm tracking-wide bg-violet-500/20 text-violet-400 hover:bg-violet-500/30 border border-violet-500/30 transition-all"
          >
            START
          </button>
        ) : (
          <button
            onClick={handlePause}
            className="px-6 py-3 rounded-xl font-semibold text-sm tracking-wide bg-rose-500/20 text-rose-400 hover:bg-rose-500/30 border border-rose-500/30 transition-all"
          >
            PAUSE
          </button>
        )}
        <button
          onClick={handleReset}
          className="px-6 py-3 rounded-xl font-semibold text-sm tracking-wide bg-white/5 text-white/60 hover:bg-white/10 border border-white/10 transition-all"
        >
          RESET
        </button>
      </div>

      {/* Presets */}
      <div className="flex gap-2 flex-wrap justify-center">
        {PRESETS.map((preset) => (
          <button
            key={preset.label}
            onClick={() => preset.seconds === 0 ? handleCustom() : handlePreset(preset.seconds)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              duration === preset.seconds && preset.seconds !== 0
                ? 'bg-violet-500/30 text-violet-300 border border-violet-500/30'
                : 'bg-white/5 text-white/40 hover:bg-white/10 border border-white/5'
            }`}
          >
            {preset.label}
          </button>
        ))}
      </div>
    </div>
  );
}
