import { useMemo } from 'react';
import { useTime } from '../hooks/useTime';

// English word clock grid: 10×11 characters
const GRID = [
  'ITLISASAMPM',
  'ACLQUARTERC',
  'TWENTYFIVEX',
  'HALFBTENFTO',
  'PASTERUNINE',
  'ONESIXTHREE',
  'FOURFIVETWO',
  'EIGHTELEVEN',
  'SEVENTWELVE',
  'TENSEOCLOCK',
];

// Map of time -> words to highlight
function getHighlightedWords(h: number, m: number) {
  const words = new Set<string>();

  // Round minutes to nearest 5
  const roundedM = Math.round(m / 5) * 5;
  const nextHour = (h % 12) + 1;

  // "IT", "IS" always on
  words.add('IT');
  words.add('IS');

  if (roundedM === 0) {
    words.add('OCLOCK');
  } else if (roundedM === 5) {
    words.add('FIVE');
    words.add('PAST');
  } else if (roundedM === 10) {
    words.add('TEN');
    words.add('PAST');
  } else if (roundedM === 15) {
    words.add('QUARTER');
    words.add('PAST');
  } else if (roundedM === 20) {
    words.add('TWENTY');
    words.add('PAST');
  } else if (roundedM === 25) {
    words.add('TWENTY');
    words.add('FIVE');
    words.add('PAST');
  } else if (roundedM === 30) {
    words.add('HALF');
    words.add('PAST');
  } else if (roundedM === 35) {
    words.add('TWENTY');
    words.add('FIVE');
    words.add('TO');
  } else if (roundedM === 40) {
    words.add('TWENTY');
    words.add('TO');
  } else if (roundedM === 45) {
    words.add('QUARTER');
    words.add('TO');
  } else if (roundedM === 50) {
    words.add('TEN');
    words.add('TO');
  } else if (roundedM === 55) {
    words.add('FIVE');
    words.add('TO');
  }

  // "AM"/"PM" - show based on actual hour
  if (h < 12) {
    words.add('AM');
  } else {
    words.add('PM');
  }

  // Hour word
  const hourWord = hourToWord(roundedM <= 30 ? h % 12 || 12 : nextHour);
  words.add(hourWord);

  return words;
}

function hourToWord(h: number): string {
  const map: Record<number, string> = {
    1: 'ONE',
    2: 'TWO',
    3: 'THREE',
    4: 'FOUR',
    5: 'FIVE',
    6: 'SIX',
    7: 'SEVEN',
    8: 'EIGHT',
    9: 'NINE',
    10: 'TEN',
    11: 'ELEVEN',
    12: 'TWELVE',
  };
  return map[h] || '';
}

// Word boundaries: where each word starts and ends (row, colStart, colEnd)
const WORD_BOUNDARIES: Record<string, [number, number, number][]> = {
  IT: [[0, 0, 1]],
  IS: [[0, 3, 4]],
  AM: [[0, 6, 7]],
  PM: [[0, 9, 10]],
  A: [[0, 0, 0]], // actually "A" is part of "AS" but used for "A" as a word
  QUARTER: [[1, 3, 9]],
  TWENTY: [
    [2, 0, 5],
    [6, 5, 10],
  ],
  FIVE: [
    [2, 6, 9],
    [8, 4, 7],
  ],
  HALF: [[3, 0, 3]],
  TEN: [
    [3, 5, 7],
    [9, 0, 2],
  ],
  TO: [
    [3, 9, 10],
    [7, 7, 8],
  ],
  PAST: [[4, 0, 3]],
  NINE: [[4, 6, 9]],
  ONE: [[5, 0, 2]],
  SIX: [[5, 3, 5]],
  THREE: [[5, 6, 10]],
  FOUR: [[6, 0, 3]],
  TWO: [[6, 8, 10]],
  EIGHT: [[7, 0, 4]],
  ELEVEN: [[7, 5, 10]],
  SEVEN: [[8, 0, 4]],
  TWELVE: [[8, 5, 10]],
  OCLOCK: [[9, 5, 10]],
};

function isCharHighlighted(
  row: number,
  col: number,
  highlightedWords: Set<string>,
): boolean {
  for (const word of highlightedWords) {
    const boundaries = WORD_BOUNDARIES[word];
    if (!boundaries) continue;
    for (const [r, cs, ce] of boundaries) {
      if (r === row && col >= cs && col <= ce) return true;
    }
  }
  return false;
}

export default function WordClock() {
  const t = useTime();
  const highlightedWords = useMemo(
    () => getHighlightedWords(t.hours, t.minutes),
    [t.hours, t.minutes],
  );

  return (
    <div className="flex flex-col items-center gap-8 animate-[fade-in_0.6s_ease-out]">
      {/* Title */}
      <div className="text-sm tracking-[0.3em] text-white/30 font-medium uppercase">
        It Is ...
      </div>

      {/* Word Grid */}
      <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-4 sm:p-6 border border-white/5 shadow-2xl">
        <div className="grid grid-cols-11 gap-x-0 gap-y-0.5 select-none">
          {GRID.map((row, ri) =>
            row.split('').map((char, ci) => {
              const highlighted = isCharHighlighted(ri, ci, highlightedWords);
              return (
                <div
                  key={`${ri}-${ci}`}
                  className={`
                    w-7 h-7 sm:w-8 sm:h-8 flex items-center justify-center
                    text-xs sm:text-sm font-semibold tracking-wider
                    transition-all duration-700 ease-in-out
                    ${
                      highlighted
                        ? 'text-indigo-300 scale-110 drop-shadow-[0_0_8px_rgba(129,140,248,0.5)]'
                        : 'text-white/15'
                    }
                  `}
                >
                  {char}
                </div>
              );
            }),
          )}
        </div>
      </div>

      {/* Current time display */}
      <div className="text-center">
        <div className="text-2xl font-light tracking-wider text-white/70 tabular-nums">
          {t.h12Str}:{t.minuteStr}
          <span className="text-sm ml-2 text-white/30">{t.ampm}</span>
        </div>
        <div className="flex gap-2 justify-center mt-3">
          {Array.from(highlightedWords)
            .filter((w) => !['IT', 'IS', 'AM', 'PM'].includes(w))
            .map((word) => (
              <span
                key={word}
                className="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/20"
              >
                {word}
              </span>
            ))}
        </div>
      </div>
    </div>
  );
}
