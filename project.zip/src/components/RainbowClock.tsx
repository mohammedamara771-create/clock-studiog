import { useTime } from '../hooks/useTime';

export default function RainbowClock() {
  const t = useTime();

  // Calculate hue based on time for rainbow effect
  const hourHue = (t.hours / 24) * 360;
  const minuteHue = (t.minutes / 60) * 360;
  const secondHue = (t.seconds / 60) * 360;

  return (
    <div className="flex flex-col items-center gap-8 animate-[fade-in_0.6s_ease-out]">
      <div className="text-sm tracking-[0.3em] text-white/30 font-medium uppercase">
        Rainbow Time
      </div>

      {/* Circular rainbow clock */}
      <div className="relative w-64 h-64 sm:w-72 sm:h-72">
        {/* Outer rainbow ring */}
        <div
          className="absolute inset-0 rounded-full"
          style={{
            background: `conic-gradient(
              from 0deg,
              hsl(0, 80%, 60%),
              hsl(60, 80%, 60%),
              hsl(120, 80%, 60%),
              hsl(180, 80%, 60%),
              hsl(240, 80%, 60%),
              hsl(300, 80%, 60%),
              hsl(360, 80%, 60%)
            )`,
            opacity: 0.3,
          }}
        />
        <div className="absolute inset-2 rounded-full bg-gray-900/90 backdrop-blur-sm" />

        {/* Hour markers */}
        {Array.from({ length: 12 }).map((_, i) => {
          const angle = (i * 30 - 90) * (Math.PI / 180);
          const r1 = 90;
          const r2 = 100;
          const x1 = 50 + r1 * Math.cos(angle);
          const y1 = 50 + r1 * Math.sin(angle);
          const x2 = 50 + r2 * Math.cos(angle);
          const y2 = 50 + r2 * Math.sin(angle);
          return (
            <line
              key={i}
              x1={`${x1}%`} y1={`${y1}%`} x2={`${x2}%`} y2={`${y2}%`}
              stroke="currentColor"
              strokeWidth="1"
              className="text-white/20"
              strokeLinecap="round"
            />
          );
        })}

        {/* Hour hand */}
        <div
          className="absolute left-1/2 top-1/2 origin-bottom rounded-full shadow-lg"
          style={{
            transform: `translate(-50%, -100%) rotate(${(t.h12 + t.minutes / 60) * 30}deg)`,
            width: 4,
            height: 60,
            background: `linear-gradient(to top, hsl(${hourHue}, 80%, 50%), hsl(${hourHue}, 80%, 70%))`,
            boxShadow: `0 0 20px hsl(${hourHue}, 80%, 50%, 0.5)`,
          }}
        />

        {/* Minute hand */}
        <div
          className="absolute left-1/2 top-1/2 origin-bottom rounded-full shadow-lg"
          style={{
            transform: `translate(-50%, -100%) rotate(${(t.minutes + t.seconds / 60) * 6}deg)`,
            width: 3,
            height: 80,
            background: `linear-gradient(to top, hsl(${minuteHue}, 80%, 50%), hsl(${minuteHue}, 80%, 70%))`,
            boxShadow: `0 0 20px hsl(${minuteHue}, 80%, 50%, 0.5)`,
          }}
        />

        {/* Second hand */}
        <div
          className="absolute left-1/2 top-1/2 origin-bottom rounded-full"
          style={{
            transform: `translate(-50%, -100%) rotate(${t.seconds * 6}deg)`,
            width: 2,
            height: 90,
            background: `linear-gradient(to top, hsl(${secondHue}, 100%, 60%), hsl(${secondHue}, 100%, 80%))`,
            boxShadow: `0 0 15px hsl(${secondHue}, 100%, 60%, 0.8)`,
          }}
        />

        {/* Center dot */}
        <div
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 rounded-full shadow-lg"
          style={{
            background: `hsl(${(hourHue + minuteHue + secondHue) / 3}, 100%, 60%)`,
            boxShadow: `0 0 20px hsl(${(hourHue + minuteHue + secondHue) / 3}, 100%, 60%, 0.8)`,
          }}
        />
      </div>

      {/* Digital display with rainbow colors */}
      <div className="text-center">
        <div className="text-3xl font-bold tracking-wider tabular-nums">
          <span style={{ color: `hsl(${hourHue}, 80%, 60%)` }}>{t.hourStr}</span>
          <span className="text-white/40">:</span>
          <span style={{ color: `hsl(${minuteHue}, 80%, 60%)` }}>{t.minuteStr}</span>
          <span className="text-white/40">:</span>
          <span style={{ color: `hsl(${secondHue}, 80%, 60%)` }}>{t.secondStr}</span>
        </div>
        <div className="text-xs text-white/30 mt-2">
          {t.ampm}
        </div>
      </div>
    </div>
  );
}
