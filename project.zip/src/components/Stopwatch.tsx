import { useState, useCallback, useEffect, useRef } from 'react';

export default function Stopwatch() {
  const [isRunning, setIsRunning] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [laps, setLaps] = useState<number[]>([]);
  const intervalRef = useRef<number | null>(null);

  useEffect(() => {
    if (isRunning) {
      const startTime = Date.now() - elapsed;
      intervalRef.current = window.setInterval(() => {
        setElapsed(Date.now() - startTime);
      }, 10);
    } else if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isRunning]);

  const handleStartStop = useCallback(() => {
    setIsRunning((prev) => !prev);
  }, []);

  const handleReset = useCallback(() => {
    setIsRunning(false);
    setElapsed(0);
    setLaps([]);
  }, []);

  const handleLap = useCallback(() => {
    setLaps((prev) => [elapsed, ...prev]);
  }, [elapsed]);

  const formatTime = (ms: number) => {
    const mins = Math.floor(ms / 60000);
    const secs = Math.floor((ms % 60000) / 1000);
    const centis = Math.floor((ms % 1000) / 10);
    return {
      mins: String(mins).padStart(2, '0'),
      secs: String(secs).padStart(2, '0'),
      centis: String(centis).padStart(2, '0'),
    };
  };

  const { mins, secs, centis } = formatTime(elapsed);

  return (
    <div className="flex flex-col items-center gap-6 animate-[fade-in_0.6s_ease-out]">
      <div className="text-sm tracking-[0.3em] text-white/30 font-medium uppercase">
        Stopwatch
      </div>

      {/* Main display */}
      <div className="bg-gradient-to-br from-emerald-500/10 to-teal-500/10 rounded-2xl p-8 border border-emerald-500/20 shadow-2xl">
        <div className="flex items-baseline justify-center gap-1">
          <span className="text-5xl sm:text-6xl font-bold text-emerald-400 drop-shadow-[0_0_20px_rgba(52,211,153,0.4)]">
            {mins}
          </span>
          <span className="text-3xl sm:text-4xl text-emerald-400/60">:</span>
          <span className="text-5xl sm:text-6xl font-bold text-emerald-400 drop-shadow-[0_0_20px_rgba(52,211,153,0.4)]">
            {secs}
          </span>
          <span className="text-2xl sm:text-3xl text-emerald-400/40">.</span>
          <span className="text-3xl sm:text-4xl font-bold text-emerald-400/60 tabular-nums">
            {centis}
          </span>
        </div>
      </div>

      {/* Controls */}
      <div className="flex gap-3">
        <button
          onClick={handleStartStop}
          className={`
            px-6 py-3 rounded-xl font-semibold text-sm tracking-wide
            transition-all duration-200
            ${
              isRunning
                ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30 border border-red-500/30'
                : 'bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 border border-emerald-500/30'
            }
          `}
        >
          {isRunning ? 'STOP' : 'START'}
        </button>
        <button
          onClick={handleLap}
          disabled={!isRunning}
          className="px-6 py-3 rounded-xl font-semibold text-sm tracking-wide bg-white/5 text-white/60 hover:bg-white/10 border border-white/10 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
        >
          LAP
        </button>
        <button
          onClick={handleReset}
          className="px-6 py-3 rounded-xl font-semibold text-sm tracking-wide bg-white/5 text-white/60 hover:bg-white/10 border border-white/10 transition-all"
        >
          RESET
        </button>
      </div>

      {/* Laps */}
      {laps.length > 0 && (
        <div className="w-full max-w-xs mt-4">
          <div className="text-xs text-white/30 uppercase tracking-wider mb-2 text-center">Laps</div>
          <div className="max-h-32 overflow-y-auto space-y-1">
            {laps.map((lap, i) => {
              const { mins: lm, secs: ls, centis: lc } = formatTime(lap);
              return (
                <div key={i} className="flex justify-between text-sm py-1 px-3 rounded-lg bg-white/5">
                  <span className="text-white/40">Lap {laps.length - i}</span>
                  <span className="text-emerald-400 tabular-nums">
                    {lm}:{ls}.{lc}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
