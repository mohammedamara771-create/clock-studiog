import { useTime } from '../hooks/useTime';

export default function DigitalLED() {
  const t = useTime();

  const LEDDigit = ({ digit }: { digit: string }) => {
    const segments: Record<string, number[]> = {
      '0': [1, 1, 1, 0, 1, 1, 1],
      '1': [0, 0, 1, 0, 0, 1, 0],
      '2': [1, 0, 1, 1, 1, 1, 0],
      '3': [1, 0, 1, 1, 0, 1, 1],
      '4': [0, 1, 1, 1, 0, 1, 0],
      '5': [1, 1, 0, 1, 0, 1, 1],
      '6': [1, 1, 0, 1, 1, 1, 1],
      '7': [1, 0, 1, 0, 0, 1, 0],
      '8': [1, 1, 1, 1, 1, 1, 1],
      '9': [1, 1, 1, 1, 0, 1, 1],
    };
    const segs = segments[digit] || [0, 0, 0, 0, 0, 0, 0];

    return (
      <div className="relative w-8 h-12 sm:w-10 sm:h-14">
        {/* Top */}
        <div className={`absolute top-0 left-1 right-1 h-1.5 rounded-sm ${segs[0] ? 'bg-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.8)]' : 'bg-gray-800/50'}`} />
        {/* Top-left */}
        <div className={`absolute top-1.5 left-0.5 w-1 h-4 rounded-sm ${segs[1] ? 'bg-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.8)]' : 'bg-gray-800/50'}`} />
        {/* Top-right */}
        <div className={`absolute top-1.5 right-0.5 w-1 h-4 rounded-sm ${segs[2] ? 'bg-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.8)]' : 'bg-gray-800/50'}`} />
        {/* Middle */}
        <div className={`absolute top-1/2 left-1 right-1 h-1.5 rounded-sm ${segs[3] ? 'bg-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.8)]' : 'bg-gray-800/50'}`} />
        {/* Bottom-left */}
        <div className={`absolute bottom-1.5 left-0.5 w-1 h-4 rounded-sm ${segs[4] ? 'bg-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.8)]' : 'bg-gray-800/50'}`} />
        {/* Bottom-right */}
        <div className={`absolute bottom-1.5 right-0.5 w-1 h-4 rounded-sm ${segs[5] ? 'bg-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.8)]' : 'bg-gray-800/50'}`} />
        {/* Bottom */}
        <div className={`absolute bottom-0 left-1 right-1 h-1.5 rounded-sm ${segs[6] ? 'bg-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.8)]' : 'bg-gray-800/50'}`} />
      </div>
    );
  };

  const Colon = () => (
    <div className="flex flex-col gap-3 mx-1">
      <div className={`w-1.5 h-1.5 rounded-full ${t.seconds % 2 === 0 ? 'bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.8)]' : 'bg-gray-800/50'}`} />
      <div className={`w-1.5 h-1.5 rounded-full ${t.seconds % 2 === 0 ? 'bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.8)]' : 'bg-gray-800/50'}`} />
    </div>
  );

  return (
    <div className="flex flex-col items-center gap-6 animate-[fade-in_0.6s_ease-out]">
      <div className="text-sm tracking-[0.3em] text-white/30 font-medium uppercase">
        LED Display
      </div>

      <div className="bg-gray-900/80 p-6 sm:p-8 rounded-2xl border border-gray-700/50 shadow-2xl">
        <div className="flex items-center">
          {t.hourStr.split('').map((d, i) => <LEDDigit key={`h${i}`} digit={d} />)}
          <Colon />
          {t.minuteStr.split('').map((d, i) => <LEDDigit key={`m${i}`} digit={d} />)}
          <Colon />
          {t.secondStr.split('').map((d, i) => <LEDDigit key={`s${i}`} digit={d} />)}
        </div>
      </div>

      <div className="text-center">
        <div className="text-2xl font-light tracking-[0.15em] text-orange-400/80">
          {t.hourStr}:{t.minuteStr}:{t.secondStr}
        </div>
        <div className="text-xs text-white/20 mt-2 font-mono">
          {new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
        </div>
      </div>
    </div>
  );
}
