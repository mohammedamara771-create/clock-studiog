import { useTime } from '../hooks/useTime';

export default function MinimalAnalogClock() {
  const t = useTime();

  // Angles in degrees
  const secondDeg = (t.seconds + t.millis / 1000) * 6;
  const minuteDeg = (t.minutes + t.seconds / 60) * 6;
  const hourDeg = (t.h12 + t.minutes / 60) * 30;

  return (
    <div className="flex flex-col items-center gap-6 animate-[fade-in_0.6s_ease-out]">
      <div className="relative w-72 h-72">
        {/* Outer ring */}
        <svg viewBox="0 0 200 200" className="absolute inset-0 w-full h-full">
          <circle cx="100" cy="100" r="92" fill="none" stroke="currentColor" strokeWidth="0.5" className="text-white/20" />
          <circle cx="100" cy="100" r="88" fill="none" stroke="currentColor" strokeWidth="0.5" className="text-white/10" strokeDasharray="2 4" />
        </svg>

        {/* Hour markers */}
        {Array.from({ length: 12 }).map((_, i) => {
          const angle = (i * 30 - 90) * (Math.PI / 180);
          const isMain = i % 3 === 0;
          const r1 = isMain ? 72 : 76;
          const r2 = isMain ? 85 : 83;
          const x1 = 100 + r1 * Math.cos(angle);
          const y1 = 100 + r1 * Math.sin(angle);
          const x2 = 100 + r2 * Math.cos(angle);
          const y2 = 100 + r2 * Math.sin(angle);
          return (
            <line
              key={i}
              x1={x1} y1={y1} x2={x2} y2={y2}
              stroke="currentColor"
              strokeWidth={isMain ? 2 : 1}
              className="text-white/60"
              strokeLinecap="round"
            />
          );
        })}

        {/* Hour hand */}
        <div
          className="absolute left-1/2 bottom-1/2 origin-bottom"
          style={{
            transform: `translateX(-50%) rotate(${hourDeg}deg)`,
            width: 3,
            height: 56,
          }}
        >
          <div className="w-full h-full rounded-full bg-gradient-to-t from-white/90 to-white/70 shadow-[0_0_12px_rgba(255,255,255,0.3)]" />
        </div>

        {/* Minute hand */}
        <div
          className="absolute left-1/2 bottom-1/2 origin-bottom"
          style={{
            transform: `translateX(-50%) rotate(${minuteDeg}deg)`,
            width: 2.5,
            height: 76,
          }}
        >
          <div className="w-full h-full rounded-full bg-gradient-to-t from-white/80 to-white/50 shadow-[0_0_10px_rgba(255,255,255,0.25)]" />
        </div>

        {/* Second hand */}
        <div
          className="absolute left-1/2 bottom-1/2 origin-bottom transition-none"
          style={{
            transform: `translateX(-50%) rotate(${secondDeg}deg)`,
            width: 1.5,
            height: 82,
          }}
        >
          <div className="w-full h-full rounded-full bg-gradient-to-t from-indigo-400 to-indigo-300 shadow-[0_0_14px_rgba(129,140,248,0.6)]" />
          {/* Counterweight */}
          <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-3 w-2.5 h-2.5 rounded-full bg-indigo-400 shadow-[0_0_8px_rgba(129,140,248,0.5)]" />
        </div>

        {/* Center dot */}
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-white shadow-[0_0_16px_rgba(255,255,255,0.5)]" />
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-indigo-400" />
      </div>

      {/* Digital readout */}
      <div className="text-center">
        <div className="text-4xl font-light tracking-[0.15em] text-white/90 tabular-nums">
          {t.h12Str}:{t.minuteStr}
          <span className="text-lg ml-2 text-white/40">{t.ampm}</span>
        </div>
        <div className="text-sm tracking-[0.2em] text-white/30 mt-1 tabular-nums">
          {t.secondStr}.{t.millisStr}
        </div>
      </div>
    </div>
  );
}
