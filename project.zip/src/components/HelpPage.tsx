import { useState } from 'react';

export default function HelpPage() {
  const [activeTab, setActiveTab] = useState<'install' | 'use' | 'clocks'>('install');

  return (
    <div className="fixed inset-0 z-50 bg-gray-950 overflow-y-auto">
      {/* Header */}
      <div className="sticky top-0 bg-gray-950/95 backdrop-blur-sm border-b border-white/10 z-10">
        <div className="max-w-2xl mx-auto px-4 py-4">
          <h1 className="text-2xl font-bold text-white text-center">💡 المساعدة</h1>
        </div>
        <div className="flex border-b border-white/10">
          <button
            onClick={() => setActiveTab('install')}
            className={`flex-1 py-3 text-sm font-medium transition-all ${
              activeTab === 'install'
                ? 'text-indigo-400 border-b-2 border-indigo-400'
                : 'text-white/40 hover:text-white/60'
            }`}
          >
            التثبيت
          </button>
          <button
            onClick={() => setActiveTab('use')}
            className={`flex-1 py-3 text-sm font-medium transition-all ${
              activeTab === 'use'
                ? 'text-indigo-400 border-b-2 border-indigo-400'
                : 'text-white/40 hover:text-white/60'
            }`}
          >
            الاستخدام
          </button>
          <button
            onClick={() => setActiveTab('clocks')}
            className={`flex-1 py-3 text-sm font-medium transition-all ${
              activeTab === 'clocks'
                ? 'text-indigo-400 border-b-2 border-indigo-400'
                : 'text-white/40 hover:text-white/60'
            }`}
          >
            الساعات
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-2xl mx-auto px-4 py-6">
        {activeTab === 'install' && <InstallTab />}
        {activeTab === 'use' && <UseTab />}
        {activeTab === 'clocks' && <ClocksTab />}
      </div>
    </div>
  );
}

function InstallTab() {
  const [platform, setPlatform] = useState<'android' | 'ios'>('android');

  return (
    <div className="space-y-6">
      {/* Platform selector */}
      <div className="flex gap-2">
        <button
          onClick={() => setPlatform('android')}
          className={`flex-1 py-3 rounded-xl font-semibold transition-all ${
            platform === 'android'
              ? 'bg-green-600 text-white'
              : 'bg-white/5 text-white/40 hover:bg-white/10'
          }`}
        >
          🤖 أندرويد
        </button>
        <button
          onClick={() => setPlatform('ios')}
          className={`flex-1 py-3 rounded-xl font-semibold transition-all ${
            platform === 'ios'
              ? 'bg-blue-600 text-white'
              : 'bg-white/5 text-white/40 hover:bg-white/10'
          }`}
        >
          🍎 آيفون
        </button>
      </div>

      {/* Steps */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-white mb-4">خطوات التثبيت</h2>

        {platform === 'android' ? (
          <>
            <Step number={1} title="افتح Chrome">
              افتح هذا الموقع في متصفح Chrome على هاتفك
            </Step>
            <Step number={2} title="اضغط النقاط الثلاث">
              اضغط على زر القائمة (النقاط الثلاث) في الزاوية العلوية
            </Step>
            <Step number={3} title="اختر 'إضافة إلى الشاشة'">
              اختر "إضافة إلى الشاشة الرئيسية" أو "تثبيت التطبيق"
            </Step>
            <Step number={4} title="أكد التثبيت">
              اضغط "إضافة" أو "تثبيت" ليظهر التطبيق على الشاشة
            </Step>
          </>
        ) : (
          <>
            <Step number={1} title="افتح Safari">
              افتح هذا الموقع في متصفح Safari على هاتفك
            </Step>
            <Step number={2} title="اضغط زر المشاركة">
              اضغط على زر المشاركة (المربع مع السهم للأعلى)
            </Step>
            <Step number={3} title="اختر 'إضافة إلى الشاشة'">
              ابحث عن "Add to Home Screen" واضغط عليه
            </Step>
            <Step number={4} title="أكد التثبيت">
              اضغط "Add" في الزاوية العلوية اليمنى
            </Step>
          </>
        )}
      </div>

      {/* Benefits */}
      <div className="bg-indigo-600/10 border border-indigo-600/30 rounded-2xl p-4">
        <h3 className="text-white font-semibold mb-3">✨ بعد التثبيت:</h3>
        <ul className="space-y-2 text-white/70">
          <li className="flex items-center gap-2">
            <span>✅</span>
            <span>التطبيق يعمل كشاشة كاملة</span>
          </li>
          <li className="flex items-center gap-2">
            <span>✅</span>
            <span>يعمل بدون إنترنت</span>
          </li>
          <li className="flex items-center gap-2">
            <span>✅</span>
            <span>أيقونة على الشاشة الرئيسية</span>
          </li>
          <li className="flex items-center gap-2">
            <span>✅</span>
            <span>12 ساعة مختلفة</span>
          </li>
        </ul>
      </div>
    </div>
  );
}

function UseTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-white">📱 الاستخدام اليومي</h2>

      <div className="space-y-4">
        <UsageCard
          icon="🏠"
          title="الشاشة الرئيسية"
          description="افتح التطبيق من الأيقونة على شاشة هاتفك"
        />
        <UsageCard
          icon="🎨"
          title="اختيار الساعة"
          description="اختر من 3 فئات: كلاسيكية، عصرية، عملية"
        />
        <UsageCard
          icon="🔒"
          title="شاشة القفل"
          description="استخدم الساعة كشاشة قفل جميلة"
        />
      </div>

      <div className="bg-amber-600/10 border border-amber-600/30 rounded-2xl p-4">
        <h3 className="text-amber-400 font-semibold mb-2">💡 نصائح توفير البطارية:</h3>
        <ul className="space-y-2 text-white/70 text-sm">
          <li>• استخدم ساعات داكنة (Analog, Flip)</li>
          <li>• تجنب الساعات الملونة (Neon, Rainbow)</li>
          <li>• أغلق الشاشة عند عدم الاستخدام</li>
        </ul>
      </div>

      <div className="bg-green-600/10 border border-green-600/30 rounded-2xl p-4">
        <h3 className="text-green-400 font-semibold mb-2">⚡ استخدام سريع:</h3>
        <div className="grid grid-cols-2 gap-3 mt-3">
          <QuickTip icon="⏱" title="Stopwatch" desc="للتمارين" />
          <QuickTip icon="⏲" title="Timer" desc="للطهي" />
          <QuickTip icon="🌍" title="World" desc="للسفر" />
          <QuickTip icon="☀" title="Solar" desc="للنهار" />
        </div>
      </div>
    </div>
  );
}

function ClocksTab() {
  const clocks = [
    { category: 'كلاسيكية', clocks: [
      { name: 'Analog', icon: '◉', desc: 'ساعة دائرية تقليدية' },
      { name: 'Flip', icon: '⟳', desc: 'بطاقات تقلب' },
      { name: 'Word', icon: 'A', desc: 'ساعة نصية' },
      { name: 'Binary', icon: '01', desc: 'ثنائية' },
    ]},
    { category: 'عصرية', clocks: [
      { name: 'Neon', icon: '⚡', desc: 'نيون مضيء' },
      { name: 'LED', icon: '7', desc: 'شاشة LED' },
      { name: 'Rainbow', icon: '🌈', desc: 'قوس قزح' },
      { name: 'Circular', icon: '◎', desc: 'دوائر تقدم' },
    ]},
    { category: 'عملية', clocks: [
      { name: 'World', icon: '🌍', desc: 'ساعات عالمية' },
      { name: 'Stopwatch', icon: '⏱', desc: 'كرونومتر' },
      { name: 'Timer', icon: '⏲', desc: 'مؤقت' },
      { name: 'Solar', icon: '☀', desc: 'شمسية' },
    ]},
  ];

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-white">🕐 جميع الساعات</h2>

      {clocks.map((category) => (
        <div key={category.category} className="space-y-3">
          <h3 className="text-lg font-medium text-indigo-400">{category.category}</h3>
          <div className="grid grid-cols-2 gap-3">
            {category.clocks.map((clock) => (
              <div
                key={clock.name}
                className="bg-white/5 rounded-xl p-4 border border-white/5 hover:border-white/10 transition-all"
              >
                <div className="text-3xl mb-2">{clock.icon}</div>
                <div className="text-white font-medium">{clock.name}</div>
                <div className="text-white/40 text-sm">{clock.desc}</div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

function Step({ number, title, children }: { number: number; title: string; children: React.ReactNode }) {
  return (
    <div className="flex gap-4">
      <div className="w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center flex-shrink-0">
        <span className="text-white font-bold">{number}</span>
      </div>
      <div className="flex-1">
        <h3 className="text-white font-medium mb-1">{title}</h3>
        <p className="text-white/60 text-sm">{children}</p>
      </div>
    </div>
  );
}

function UsageCard({ icon, title, description }: { icon: string; title: string; description: string }) {
  return (
    <div className="bg-white/5 rounded-xl p-4 border border-white/5">
      <div className="flex items-center gap-3">
        <span className="text-3xl">{icon}</span>
        <div>
          <h3 className="text-white font-medium">{title}</h3>
          <p className="text-white/60 text-sm">{description}</p>
        </div>
      </div>
    </div>
  );
}

function QuickTip({ icon, title, desc }: { icon: string; title: string; desc: string }) {
  return (
    <div className="bg-white/5 rounded-lg p-3 text-center">
      <div className="text-2xl mb-1">{icon}</div>
      <div className="text-white text-sm font-medium">{title}</div>
      <div className="text-white/40 text-xs">{desc}</div>
    </div>
  );
}
