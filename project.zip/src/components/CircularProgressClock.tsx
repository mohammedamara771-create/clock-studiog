import { useTime } from '../hooks/useTime';

export default function CircularProgressClock() {
  const t = useTime();

  // Progress values (0-100)
  const secondProgress = (t.seconds / 60) * 100;
  const minuteProgress = ((t.minutes * 60 + t.seconds) / 3600) * 100;
  const hourProgress = (((t.h12 * 60 + t.minutes) * 60 + t.seconds) / 43200) * 100;

  const Circle = ({ progress, color, size, strokeWidth, label }: {
    progress: number;
    color: string;
    size: number;
    strokeWidth: number;
    label: string;
  }) => {
    const radius = (size - strokeWidth) / 2;
    const circumference = radius * 2 * Math.PI;
    const offset = circumference - (progress / 100) * circumference;

    return (
      <div className="absolute inset-0 flex items-center justify-center">
        <svg width={size} height={size} className="transform -rotate-90">
          {/* Background circle */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="currentColor"
            strokeWidth={strokeWidth}
            className="text-white/5"
          />
          {/* Progress circle */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={color}
            strokeWidth={strokeWidth}
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            className="transition-all duration-300"
            style={{ filter: `drop-shadow(0 0 8px ${color}50)` }}
          />
        </svg>
        <div className="absolute text-center">
          <div className="text-2xl font-semibold text-white/80 tabular-nums">
            {label}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="flex flex-col items-center gap-8 animate-[fade-in_0.6s_ease-out]">
      <div className="text-sm tracking-[0.3em] text-white/30 font-medium uppercase">
        Progress Circles
      </div>

      {/* Concentric circles */}
      <div className="relative w-56 h-56">
        <Circle
          progress={hourProgress}
          color="#818cf8"
          size={224}
          strokeWidth={8}
          label={String(t.h12).padStart(2, '0')}
        />
        <Circle
          progress={minuteProgress}
          color="#34d399"
          size={188}
          strokeWidth={6}
          label={String(t.minutes).padStart(2, '0')}
        />
        <Circle
          progress={secondProgress}
          color="#f472b6"
          size={152}
          strokeWidth={4}
          label={String(t.seconds).padStart(2, '0')}
        />
      </div>

      {/* Legend */}
      <div className="flex gap-6 text-xs">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-indigo-400" />
          <span className="text-white/40">Hours</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-400" />
          <span className="text-white/40">Minutes</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-pink-400" />
          <span className="text-white/40">Seconds</span>
        </div>
      </div>

      {/* Full time */}
      <div className="text-2xl font-light tracking-widest text-white/60 tabular-nums">
        {t.hourStr}:{t.minuteStr}:{t.secondStr}
      </div>
    </div>
  );
}
