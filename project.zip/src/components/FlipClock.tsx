import { useState, useEffect, useRef } from 'react';
import { useTime } from '../hooks/useTime';

function FlipCard({ value, label, prev }: { value: string; label: string; prev?: string }) {
  const [flipping, setFlipping] = useState(false);
  const prevValue = useRef(value);

  useEffect(() => {
    if (prevValue.current !== value) {
      setFlipping(true);
      const timer = setTimeout(() => {
        prevValue.current = value;
        setFlipping(false);
      }, 600);
      return () => clearTimeout(timer);
    }
  }, [value]);

  return (
    <div className="flex flex-col items-center gap-3">
      <div className="relative">
        <div className="relative w-20 h-28 sm:w-24 sm:h-32 rounded-xl overflow-hidden shadow-2xl">
          {/* Background */}
          <div className="absolute inset-0 bg-gradient-to-b from-gray-800 to-gray-900 rounded-xl" />
          <div className="absolute inset-x-0 top-1/2 h-px bg-black/40 z-10" />

          {/* Upper half (always shows current) */}
          <div className="absolute inset-x-0 top-0 h-1/2 overflow-hidden rounded-t-xl bg-gradient-to-b from-gray-700 to-gray-800">
            <div className="flex items-center justify-center h-full">
              <span className="text-3xl sm:text-4xl font-bold text-white/90 tabular-nums -mt-1">
                {value}
              </span>
            </div>
          </div>

          {/* Lower half (always shows current) */}
          <div className="absolute inset-x-0 bottom-0 h-1/2 overflow-hidden rounded-b-xl bg-gray-800">
            <div className="flex items-center justify-center h-full">
              <span className="text-3xl sm:text-4xl font-bold text-white/70 tabular-nums -mb-1">
                {value}
              </span>
            </div>
          </div>

          {/* Flip animation overlay - upper half (old value) */}
          <div
            className={`absolute inset-x-0 top-0 h-1/2 overflow-hidden rounded-t-xl bg-gradient-to-b from-gray-700 to-gray-800 origin-bottom transition-transform duration-[400ms] ${
              flipping ? 'scale-y-0' : ''
            }`}
            style={{ transformStyle: 'preserve-3d', backfaceVisibility: 'hidden' }}
          >
            <div className="flex items-center justify-center h-full">
              <span className="text-3xl sm:text-4xl font-bold text-white/90 tabular-nums -mt-1">
                {prev ?? value}
              </span>
            </div>
          </div>

          {/* Flip animation overlay - lower half (new value) */}
          <div
            className={`absolute inset-x-0 bottom-0 h-1/2 overflow-hidden rounded-b-xl bg-gray-800 origin-top transition-transform duration-[400ms] ${
              flipping ? 'scale-y-100' : 'scale-y-0'
            }`}
            style={{ transformStyle: 'preserve-3d', backfaceVisibility: 'hidden' }}
          >
            <div className="flex items-center justify-center h-full">
              <span className="text-3xl sm:text-4xl font-bold text-white/70 tabular-nums -mb-1">
                {value}
              </span>
            </div>
          </div>

          {/* Edge highlight */}
          <div className="absolute inset-0 rounded-xl ring-1 ring-white/5 pointer-events-none" />
          <div className="absolute inset-x-0 top-1/2 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent z-20" />
        </div>
      </div>
      <span className="text-[10px] uppercase tracking-[0.2em] text-white/30 font-medium">{label}</span>
    </div>
  );
}

export default function FlipClock() {
  const t = useTime();
  const prev = useRef({ h: t.h12Str, m: t.minuteStr, s: t.secondStr });

  // Debounce prev updates to not jump mid-animation
  const [prevVals, setPrevVals] = useState({ h: '', m: '', s: '' });

  useEffect(() => {
    // small delay so we know the flip animation target
    const timer = setTimeout(() => {
      setPrevVals({ h: prev.current.h, m: prev.current.m, s: prev.current.s });
      prev.current = { h: t.h12Str, m: t.minuteStr, s: t.secondStr };
    }, 50);
    return () => clearTimeout(timer);
  }, [t.h12Str, t.minuteStr, t.secondStr]);

  return (
    <div className="flex flex-col items-center gap-8 animate-[fade-in_0.6s_ease-out]">
      {/* AM/PM indicator */}
      <div className="text-sm tracking-[0.3em] text-white/40 font-medium uppercase">{t.ampm}</div>

      <div className="flex items-center gap-3 sm:gap-4">
        <FlipCard value={t.h12Str} label="Hour" prev={prevVals.h} />
        <div className="flex flex-col items-center justify-center gap-1 mt-[-1.5rem]">
          <div className="w-2 h-2 rounded-full bg-indigo-400 shadow-[0_0_8px_rgba(129,140,248,0.6)]" />
          <div className="w-2 h-2 rounded-full bg-indigo-400/60 shadow-[0_0_6px_rgba(129,140,248,0.4)]" />
        </div>
        <FlipCard value={t.minuteStr} label="Min" prev={prevVals.m} />
        <div className="flex flex-col items-center justify-center gap-1 mt-[-1.5rem]">
          <div className="w-2 h-2 rounded-full bg-indigo-400 shadow-[0_0_8px_rgba(129,140,248,0.6)]" />
          <div className="w-2 h-2 rounded-full bg-indigo-400/60 shadow-[0_0_6px_rgba(129,140,248,0.4)]" />
        </div>
        <FlipCard value={t.secondStr} label="Sec" prev={prevVals.s} />
      </div>

      {/* Progress bar */}
      <div className="w-64 h-0.5 rounded-full bg-white/5 overflow-hidden">
        <div
          className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-violet-400 transition-all duration-300"
          style={{ width: `${(t.seconds / 60) * 100}%` }}
        />
      </div>
    </div>
  );
}
