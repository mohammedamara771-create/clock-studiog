import { useTime } from '../hooks/useTime';

export default function NeonClock() {
  const t = useTime();

  return (
    <div className="flex flex-col items-center gap-8 animate-[fade-in_0.6s_ease-out]">
      <div className="text-sm tracking-[0.3em] text-white/30 font-medium uppercase">
        Neon Time
      </div>

      {/* Neon tube display */}
      <div className="flex items-baseline gap-1 sm:gap-2 p-6 sm:p-8 rounded-2xl bg-black/40 border border-white/5 shadow-2xl">
        {/* Hours */}
        <div className="flex gap-1 sm:gap-2">
          {t.h12Str.split('').map((digit, i) => (
            <div key={`h${i}`} className="relative">
              <div className="text-4xl sm:text-5xl font-bold text-cyan-300 drop-shadow-[0_0_15px_rgba(103,232,249,0.8)]">
                {digit}
              </div>
            </div>
          ))}
        </div>

        {/* Colon */}
        <div className="flex flex-col gap-2 sm:gap-3 mx-1 sm:mx-2">
          <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-pink-400 shadow-[0_0_10px_rgba(244,114,182,0.8)] animate-pulse" />
          <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-pink-400 shadow-[0_0_10px_rgba(244,114,182,0.8)] animate-pulse" />
        </div>

        {/* Minutes */}
        <div className="flex gap-1 sm:gap-2">
          {t.minuteStr.split('').map((digit, i) => (
            <div key={`m${i}`} className="relative">
              <div className="text-4xl sm:text-5xl font-bold text-pink-400 drop-shadow-[0_0_15px_rgba(244,114,182,0.8)]">
                {digit}
              </div>
            </div>
          ))}
        </div>

        {/* Colon */}
        <div className="flex flex-col gap-2 sm:gap-3 mx-1 sm:mx-2">
          <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-lime-400 shadow-[0_0_10px_rgba(163,230,53,0.8)] animate-pulse" />
          <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-lime-400 shadow-[0_0_10px_rgba(163,230,53,0.8)] animate-pulse" />
        </div>

        {/* Seconds */}
        <div className="flex gap-1 sm:gap-2">
          {t.secondStr.split('').map((digit, i) => (
            <div key={`s${i}`} className="relative">
              <div className="text-4xl sm:text-5xl font-bold text-lime-400 drop-shadow-[0_0_15px_rgba(163,230,53,0.8)]">
                {digit}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* AM/PM */}
      <div className="text-2xl font-bold tracking-widest text-purple-400 drop-shadow-[0_0_20px_rgba(192,132,252,0.6)]">
        {t.ampm}
      </div>

      {/* Date */}
      <div className="text-sm tracking-wider text-white/40">
        {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
      </div>
    </div>
  );
}
