import { useState, useEffect } from 'react';
import MinimalAnalogClock from './components/MinimalAnalogClock';
import FlipClock from './components/FlipClock';
import WordClock from './components/WordClock';
import BinaryClock from './components/BinaryClock';
import NeonClock from './components/NeonClock';
import DigitalLED from './components/DigitalLEDClock';
import WorldClock from './components/WorldClock';
import Stopwatch from './components/Stopwatch';
import RainbowClock from './components/RainbowClock';
import CircularProgressClock from './components/CircularProgressClock';
import SolarClock from './components/SolarClock';
import CountdownTimer from './components/CountdownTimer';
import InstallGuide from './components/InstallGuide';
import HelpPage from './components/HelpPage';
import { usePWA } from './hooks/usePWA';

type ClockType = 
  | 'analog' | 'flip' | 'word' | 'binary'
  | 'neon' | 'led' | 'world' | 'stopwatch'
  | 'rainbow' | 'circular' | 'solar' | 'countdown';

interface ClockInfo {
  id: ClockType;
  label: string;
  icon: string;
  color: string;
}

interface Category {
  name: string;
  clocks: ClockInfo[];
}

const clockCategories: Category[] = [
  {
    name: 'Classic',
    clocks: [
      { id: 'analog' as const, label: 'Analog', icon: '◉', color: 'from-indigo-500 to-violet-600' },
      { id: 'flip' as const, label: 'Flip', icon: '⟳', color: 'from-amber-500 to-orange-600' },
      { id: 'word' as const, label: 'Word', icon: 'A', color: 'from-emerald-500 to-teal-600' },
      { id: 'binary' as const, label: 'Binary', icon: '01', color: 'from-cyan-500 to-blue-600' },
    ]
  },
  {
    name: 'Modern',
    clocks: [
      { id: 'neon' as const, label: 'Neon', icon: '⚡', color: 'from-pink-500 to-rose-600' },
      { id: 'led' as const, label: 'LED', icon: '7', color: 'from-orange-500 to-red-600' },
      { id: 'rainbow' as const, label: 'Rainbow', icon: '🌈', color: 'from-purple-500 to-fuchsia-600' },
      { id: 'circular' as const, label: 'Circular', icon: '◎', color: 'from-green-500 to-emerald-600' },
    ]
  },
  {
    name: 'Utility',
    clocks: [
      { id: 'world' as const, label: 'World', icon: '🌍', color: 'from-blue-500 to-indigo-600' },
      { id: 'stopwatch' as const, label: 'Stopwatch', icon: '⏱', color: 'from-red-500 to-pink-600' },
      { id: 'countdown' as const, label: 'Timer', icon: '⏲', color: 'from-violet-500 to-purple-600' },
      { id: 'solar' as const, label: 'Solar', icon: '☀', color: 'from-yellow-500 to-orange-600' },
    ]
  }
];

function getClockComponent(id: ClockType) {
  switch (id) {
    case 'analog': return <MinimalAnalogClock />;
    case 'flip': return <FlipClock />;
    case 'word': return <WordClock />;
    case 'binary': return <BinaryClock />;
    case 'neon': return <NeonClock />;
    case 'led': return <DigitalLED />;
    case 'world': return <WorldClock />;
    case 'stopwatch': return <Stopwatch />;
    case 'rainbow': return <RainbowClock />;
    case 'circular': return <CircularProgressClock />;
    case 'solar': return <SolarClock />;
    case 'countdown': return <CountdownTimer />;
    default: return <MinimalAnalogClock />;
  }
}

export default function App() {
  const [activeClock, setActiveClock] = useState<ClockType>('analog');
  const [activeCategory, setActiveCategory] = useState(0);
  const [showHelp, setShowHelp] = useState(false);
  const { canInstall, installApp, isInstalled } = usePWA();

  useEffect(() => {
    // Check URL params for clock selection
    const params = new URLSearchParams(window.location.search);
    const clockParam = params.get('clock');
    if (clockParam) {
      setActiveClock(clockParam as ClockType);
    }
  }, []);

  const activeClockData = clockCategories
    .flatMap(c => c.clocks)
    .find(c => c.id === activeClock);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-slate-900 to-gray-950 flex flex-col items-center p-4 sm:p-6 relative overflow-hidden">
      {/* Install PWA Banner */}
      {canInstall && !isInstalled && (
        <div className="fixed top-4 left-4 right-4 z-50 animate-[fade-in_0.3s_ease-out]">
          <div className="bg-gradient-to-r from-indigo-600 to-violet-600 text-white px-4 py-3 rounded-xl shadow-2xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-2xl">📱</span>
              <div>
                <div className="font-semibold text-sm">Install Clock Studio</div>
                <div className="text-xs text-white/70">Get the app on your phone</div>
              </div>
            </div>
            <button
              onClick={installApp}
              className="bg-white/20 hover:bg-white/30 px-4 py-2 rounded-lg text-sm font-semibold transition-all"
            >
              Install
            </button>
          </div>
        </div>
      )}
      {/* Background effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-violet-500/10 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-indigo-500/5 rounded-full blur-3xl" />
      </div>

      {/* Header */}
      <div className="relative z-10 mb-6 text-center">
        <h1 className="text-xl sm:text-2xl font-light tracking-[0.2em] text-white/80">
          CLOCK STUDIO
        </h1>
        <div className="h-px w-20 mx-auto mt-2 bg-gradient-to-r from-transparent via-indigo-400/50 to-transparent" />
        <button
          onClick={() => setShowHelp(true)}
          className="mt-3 text-white/40 hover:text-white/80 transition-colors"
        >
          <span className="text-sm">💡 المساعدة</span>
        </button>
      </div>

      {/* Category tabs */}
      <nav className="relative z-10 flex gap-1 mb-6 bg-white/5 backdrop-blur-sm rounded-xl p-1 border border-white/5">
        {clockCategories.map((category, i) => (
          <button
            key={category.name}
            onClick={() => setActiveCategory(i)}
            className={`
              px-4 py-2 rounded-lg text-xs font-medium tracking-wide
              transition-all duration-200
              ${
                activeCategory === i
                  ? 'text-white bg-white/10 shadow-lg'
                  : 'text-white/40 hover:text-white/60 hover:bg-white/5'
              }
            `}
          >
            {category.name}
          </button>
        ))}
      </nav>

      {/* Clock selector grid */}
      <div className="relative z-10 grid grid-cols-4 gap-2 mb-6">
        {clockCategories[activeCategory].clocks.map(({ id, label, icon, color }) => (
          <button
            key={id}
            onClick={() => setActiveClock(id)}
            className={`
              flex flex-col items-center gap-1 p-3 rounded-xl
              transition-all duration-300 ease-out
              ${
                activeClock === id
                  ? `bg-gradient-to-br ${color} shadow-lg scale-105`
                  : 'bg-white/5 hover:bg-white/10 text-white/60 hover:text-white/80'
              }
            `}
          >
            <span className="text-lg">{icon}</span>
            <span className="text-[10px] font-medium">{label}</span>
          </button>
        ))}
      </div>

      {/* Clock display */}
      <div className="relative z-10 w-full max-w-md flex-1 flex items-center justify-center">
        <div className="w-full bg-white/[0.03] backdrop-blur-sm rounded-3xl p-6 border border-white/5 shadow-2xl">
          <div key={activeClock} className="transition-all duration-500 ease-in-out">
            {getClockComponent(activeClock)}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="relative z-10 mt-6 text-center">
        <div className="text-xs text-white/20">
          {activeClockData && activeClockData.label} Clock
        </div>
      </div>

      {/* Install Guide */}
      <InstallGuide />
    </div>
  );
}
